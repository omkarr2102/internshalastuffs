<?php
include_once('link.php');

?>

<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
			<a href="#" class="navbar-brand">SignIn SignUP Form</a>
</nav>